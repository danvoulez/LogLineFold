"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
} from "recharts"
import { Play, Pause, RotateCcw, TrendingUp, Zap, Activity, Bold as Fold } from "lucide-react"

interface TimePoint {
  time: number
  expression: number
  folding: number
  entropy: number
  stability: number
}

interface ProteinSpan {
  id: string
  name: string
  start: number
  end: number
  foldState: "folded" | "unfolded" | "intermediate"
  expression: number
}

export function SpanTimeline() {
  const [currentTime, setCurrentTime] = useState([0])
  const [isPlaying, setIsPlaying] = useState(false)
  const [playbackSpeed, setPlaybackSpeed] = useState([1])
  const [selectedSpan, setSelectedSpan] = useState<string | null>(null)
  const [foldingThreshold, setFoldingThreshold] = useState([0.5])

  // Generate sample timeline data
  const [timelineData, setTimelineData] = useState<TimePoint[]>(() => {
    return Array.from({ length: 100 }, (_, i) => ({
      time: i,
      expression: 50 + 30 * Math.sin(i * 0.1) + 10 * Math.random(),
      folding: 40 + 25 * Math.cos(i * 0.08) + 15 * Math.random(),
      entropy: 30 + 20 * Math.sin(i * 0.12 + 1) + 8 * Math.random(),
      stability: 60 + 20 * Math.cos(i * 0.06 + 0.5) + 12 * Math.random(),
    }))
  })

  // Sample protein spans
  const [proteinSpans, setProteinSpans] = useState<ProteinSpan[]>([
    { id: "span1", name: "Alpha Helix", start: 10, end: 30, foldState: "folded", expression: 75 },
    { id: "span2", name: "Beta Sheet", start: 35, end: 55, foldState: "intermediate", expression: 60 },
    { id: "span3", name: "Loop Region", start: 60, end: 80, foldState: "unfolded", expression: 45 },
    { id: "span4", name: "Turn Motif", start: 85, end: 95, foldState: "folded", expression: 80 },
  ])

  // Animation loop
  useEffect(() => {
    if (!isPlaying) return

    const interval = setInterval(() => {
      setCurrentTime((prev) => {
        const newTime = prev[0] + playbackSpeed[0]
        return [newTime >= 99 ? 0 : newTime]
      })
    }, 100)

    return () => clearInterval(interval)
  }, [isPlaying, playbackSpeed])

  // Update protein spans based on current time and folding threshold
  useEffect(() => {
    const currentData = timelineData[Math.floor(currentTime[0])]
    if (!currentData) return

    setProteinSpans((prev) =>
      prev.map((span) => {
        const foldingLevel = currentData.folding / 100
        let newFoldState: "folded" | "unfolded" | "intermediate"

        if (foldingLevel > foldingThreshold[0] + 0.2) {
          newFoldState = "folded"
        } else if (foldingLevel < foldingThreshold[0] - 0.2) {
          newFoldState = "unfolded"
        } else {
          newFoldState = "intermediate"
        }

        return {
          ...span,
          foldState: newFoldState,
          expression: Math.max(0, Math.min(100, span.expression + (Math.random() - 0.5) * 5)),
        }
      }),
    )
  }, [currentTime, foldingThreshold])

  const currentData = timelineData[Math.floor(currentTime[0])] || timelineData[0]

  const getFoldStateColor = (state: string) => {
    switch (state) {
      case "folded":
        return "bg-chart-1"
      case "intermediate":
        return "bg-chart-2"
      case "unfolded":
        return "bg-chart-3"
      default:
        return "bg-muted"
    }
  }

  const getFoldStateText = (state: string) => {
    switch (state) {
      case "folded":
        return "Folded"
      case "intermediate":
        return "Intermediate"
      case "unfolded":
        return "Unfolded"
      default:
        return "Unknown"
    }
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="timeline" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="timeline">Timeline View</TabsTrigger>
          <TabsTrigger value="folding">Span Folding</TabsTrigger>
          <TabsTrigger value="entropy">ΔS Visualizer</TabsTrigger>
        </TabsList>

        <TabsContent value="timeline" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                Protein Expression Timeline
              </CardTitle>
              <CardDescription>Real-time visualization of protein expression and folding dynamics</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Timeline Controls */}
              <div className="flex items-center gap-4 p-4 bg-muted/50 rounded-lg">
                <Button variant={isPlaying ? "default" : "outline"} size="sm" onClick={() => setIsPlaying(!isPlaying)}>
                  {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                </Button>
                <Button variant="outline" size="sm" onClick={() => setCurrentTime([0])}>
                  <RotateCcw className="h-4 w-4" />
                </Button>
                <div className="flex-1 space-y-2">
                  <Label>Time: {currentTime[0].toFixed(1)}s</Label>
                  <Slider value={currentTime} onValueChange={setCurrentTime} max={99} step={0.1} className="w-full" />
                </div>
                <div className="space-y-2">
                  <Label>Speed: {playbackSpeed[0]}x</Label>
                  <Slider
                    value={playbackSpeed}
                    onValueChange={setPlaybackSpeed}
                    min={0.1}
                    max={3}
                    step={0.1}
                    className="w-24"
                  />
                </div>
              </div>

              {/* Expression Chart */}
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={timelineData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis />
                    <Tooltip />
                    <Line
                      type="monotone"
                      dataKey="expression"
                      stroke="rgb(var(--chart-1))"
                      strokeWidth={2}
                      name="Expression Level"
                    />
                    <Line
                      type="monotone"
                      dataKey="folding"
                      stroke="rgb(var(--chart-2))"
                      strokeWidth={2}
                      name="Folding State"
                    />
                    <Line
                      type="monotone"
                      dataKey="stability"
                      stroke="rgb(var(--chart-4))"
                      strokeWidth={2}
                      name="Stability"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              {/* Current Values */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2">
                      <TrendingUp className="h-4 w-4 text-chart-1" />
                      <span className="text-sm font-medium">Expression</span>
                    </div>
                    <div className="text-2xl font-bold">{currentData.expression.toFixed(1)}%</div>
                    <Progress value={currentData.expression} className="mt-2" />
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2">
                      <Fold className="h-4 w-4 text-chart-2" />
                      <span className="text-sm font-medium">Folding</span>
                    </div>
                    <div className="text-2xl font-bold">{currentData.folding.toFixed(1)}%</div>
                    <Progress value={currentData.folding} className="mt-2" />
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2">
                      <Zap className="h-4 w-4 text-chart-3" />
                      <span className="text-sm font-medium">Entropy</span>
                    </div>
                    <div className="text-2xl font-bold">{currentData.entropy.toFixed(1)}</div>
                    <Progress value={currentData.entropy} className="mt-2" />
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2">
                      <Activity className="h-4 w-4 text-chart-4" />
                      <span className="text-sm font-medium">Stability</span>
                    </div>
                    <div className="text-2xl font-bold">{currentData.stability.toFixed(1)}%</div>
                    <Progress value={currentData.stability} className="mt-2" />
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="folding" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Fold className="h-5 w-5" />
                Protein Span Folding
              </CardTitle>
              <CardDescription>Monitor and control protein folding states across different spans</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Folding Controls */}
              <div className="space-y-2">
                <Label>Folding Threshold: {foldingThreshold[0].toFixed(2)}</Label>
                <Slider
                  value={foldingThreshold}
                  onValueChange={setFoldingThreshold}
                  min={0}
                  max={1}
                  step={0.01}
                  className="w-full"
                />
              </div>

              {/* Protein Spans */}
              <div className="space-y-3">
                {proteinSpans.map((span) => (
                  <Card
                    key={span.id}
                    className={`cursor-pointer transition-all ${selectedSpan === span.id ? "ring-2 ring-primary" : ""}`}
                    onClick={() => setSelectedSpan(selectedSpan === span.id ? null : span.id)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`w-4 h-4 rounded-full ${getFoldStateColor(span.foldState)}`} />
                          <div>
                            <div className="font-medium">{span.name}</div>
                            <div className="text-sm text-muted-foreground">
                              Residues {span.start}-{span.end}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge variant="outline">{getFoldStateText(span.foldState)}</Badge>
                          <div className="text-sm text-muted-foreground mt-1">
                            {span.expression.toFixed(1)}% expression
                          </div>
                        </div>
                      </div>
                      {selectedSpan === span.id && (
                        <div className="mt-4 pt-4 border-t">
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="font-medium">Length:</span> {span.end - span.start + 1} residues
                            </div>
                            <div>
                              <span className="font-medium">Position:</span> {span.start}-{span.end}
                            </div>
                          </div>
                          <Progress value={span.expression} className="mt-2" />
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="entropy" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5" />
                ΔS Entropy Visualizer
              </CardTitle>
              <CardDescription>Analyze entropy changes and thermodynamic properties over time</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Entropy Chart */}
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={timelineData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis />
                    <Tooltip />
                    <Area
                      type="monotone"
                      dataKey="entropy"
                      stroke="rgb(var(--chart-3))"
                      fill="rgb(var(--chart-3) / 0.3)"
                      name="Entropy (ΔS)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              {/* Entropy Statistics */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-chart-3">{currentData.entropy.toFixed(2)}</div>
                    <div className="text-sm text-muted-foreground">Current ΔS</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-chart-1">
                      {Math.max(...timelineData.map((d) => d.entropy)).toFixed(2)}
                    </div>
                    <div className="text-sm text-muted-foreground">Max ΔS</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-chart-2">
                      {(timelineData.reduce((sum, d) => sum + d.entropy, 0) / timelineData.length).toFixed(2)}
                    </div>
                    <div className="text-sm text-muted-foreground">Average ΔS</div>
                  </CardContent>
                </Card>
              </div>

              {/* Entropy Distribution */}
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={timelineData.slice(0, 20)}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="entropy" fill="rgb(var(--chart-3))" name="Entropy Distribution" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
