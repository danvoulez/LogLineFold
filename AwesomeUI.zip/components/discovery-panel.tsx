"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Textarea } from "@/components/ui/textarea"
import { Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts"
import {
  Eye,
  Brain,
  Lightbulb,
  Play,
  FileText,
  Clock,
  CheckCircle,
  AlertCircle,
  TrendingUp,
  Search,
  Beaker,
} from "lucide-react"

interface Discovery {
  id: string
  title: string
  phase: "observe" | "reflect" | "invent" | "execute" | "completed"
  timestamp: Date
  observations: string[]
  reflections: string[]
  hypotheses: string[]
  experiments: string[]
  results: string[]
  confidence: number
  impact: number
}

interface AuditEntry {
  id: string
  discoveryId: string
  phase: string
  action: string
  timestamp: Date
  details: string
  user: string
}

export function DiscoveryPanel() {
  const [discoveries, setDiscoveries] = useState<Discovery[]>([
    {
      id: "disc-001",
      title: "Protein Folding Anomaly in Alpha Helix",
      phase: "reflect",
      timestamp: new Date(Date.now() - 86400000),
      observations: [
        "Unusual folding pattern detected at position 45-67",
        "Temperature sensitivity increased by 15%",
        "Hydrophobic interactions disrupted",
      ],
      reflections: [
        "Pattern suggests potential misfolding cascade",
        "Similar to known prion-related structures",
        "May indicate novel therapeutic target",
      ],
      hypotheses: [
        "Mutation at position 52 causes structural instability",
        "Chaperone protein interaction is compromised",
      ],
      experiments: ["Site-directed mutagenesis at position 52", "Chaperone binding affinity assay"],
      results: [],
      confidence: 75,
      impact: 85,
    },
    {
      id: "disc-002",
      title: "Novel Enzyme Kinetics in Metabolic Pathway",
      phase: "execute",
      timestamp: new Date(Date.now() - 172800000),
      observations: [
        "Enzyme activity 3x higher than expected",
        "Substrate specificity broader than literature",
        "pH optimum shifted to 6.2",
      ],
      reflections: [
        "Evolutionary adaptation to acidic environment",
        "Potential industrial applications",
        "Regulatory mechanism unknown",
      ],
      hypotheses: ["Active site modification enhances catalysis", "Allosteric regulation by unknown cofactor"],
      experiments: ["Crystal structure determination", "Cofactor screening assay", "Kinetic parameter measurement"],
      results: ["Crystal structure shows novel active site geometry", "Mg2+ cofactor increases activity 2-fold"],
      confidence: 90,
      impact: 70,
    },
  ])

  const [selectedDiscovery, setSelectedDiscovery] = useState<string>("disc-001")
  const [currentPhase, setCurrentPhase] = useState<string>("observe")
  const [newObservation, setNewObservation] = useState("")
  const [newReflection, setNewReflection] = useState("")
  const [newHypothesis, setNewHypothesis] = useState("")
  const [newExperiment, setNewExperiment] = useState("")

  const [auditLog, setAuditLog] = useState<AuditEntry[]>([
    {
      id: "audit-001",
      discoveryId: "disc-001",
      phase: "observe",
      action: "Added observation",
      timestamp: new Date(Date.now() - 3600000),
      details: "Recorded unusual folding pattern",
      user: "dan",
    },
    {
      id: "audit-002",
      discoveryId: "disc-002",
      phase: "execute",
      action: "Completed experiment",
      timestamp: new Date(Date.now() - 7200000),
      details: "Crystal structure determination finished",
      user: "dan",
    },
  ])

  const selectedDiscoveryData = discoveries.find((d) => d.id === selectedDiscovery)

  const phaseColors = {
    observe: "bg-blue-500",
    reflect: "bg-purple-500",
    invent: "bg-yellow-500",
    execute: "bg-green-500",
    completed: "bg-gray-500",
  }

  const phaseIcons = {
    observe: Eye,
    reflect: Brain,
    invent: Lightbulb,
    execute: Play,
    completed: CheckCircle,
  }

  const addAuditEntry = (discoveryId: string, phase: string, action: string, details: string) => {
    const newEntry: AuditEntry = {
      id: `audit-${Date.now()}`,
      discoveryId,
      phase,
      action,
      timestamp: new Date(),
      details,
      user: "dan",
    }
    setAuditLog((prev) => [newEntry, ...prev])
  }

  const addObservation = () => {
    if (!newObservation.trim() || !selectedDiscoveryData) return

    setDiscoveries((prev) =>
      prev.map((d) => (d.id === selectedDiscovery ? { ...d, observations: [...d.observations, newObservation] } : d)),
    )

    addAuditEntry(selectedDiscovery, "observe", "Added observation", newObservation)
    setNewObservation("")
  }

  const addReflection = () => {
    if (!newReflection.trim() || !selectedDiscoveryData) return

    setDiscoveries((prev) =>
      prev.map((d) => (d.id === selectedDiscovery ? { ...d, reflections: [...d.reflections, newReflection] } : d)),
    )

    addAuditEntry(selectedDiscovery, "reflect", "Added reflection", newReflection)
    setNewReflection("")
  }

  const addHypothesis = () => {
    if (!newHypothesis.trim() || !selectedDiscoveryData) return

    setDiscoveries((prev) =>
      prev.map((d) => (d.id === selectedDiscovery ? { ...d, hypotheses: [...d.hypotheses, newHypothesis] } : d)),
    )

    addAuditEntry(selectedDiscovery, "invent", "Added hypothesis", newHypothesis)
    setNewHypothesis("")
  }

  const addExperiment = () => {
    if (!newExperiment.trim() || !selectedDiscoveryData) return

    setDiscoveries((prev) =>
      prev.map((d) => (d.id === selectedDiscovery ? { ...d, experiments: [...d.experiments, newExperiment] } : d)),
    )

    addAuditEntry(selectedDiscovery, "execute", "Added experiment", newExperiment)
    setNewExperiment("")
  }

  const advancePhase = () => {
    if (!selectedDiscoveryData) return

    const phases = ["observe", "reflect", "invent", "execute", "completed"]
    const currentIndex = phases.indexOf(selectedDiscoveryData.phase)
    const nextPhase = phases[Math.min(currentIndex + 1, phases.length - 1)]

    setDiscoveries((prev) => prev.map((d) => (d.id === selectedDiscovery ? { ...d, phase: nextPhase as any } : d)))

    addAuditEntry(selectedDiscovery, nextPhase, "Advanced phase", `Moved to ${nextPhase} phase`)
  }

  const createNewDiscovery = () => {
    const newDiscovery: Discovery = {
      id: `disc-${Date.now()}`,
      title: "New Discovery",
      phase: "observe",
      timestamp: new Date(),
      observations: [],
      reflections: [],
      hypotheses: [],
      experiments: [],
      results: [],
      confidence: 50,
      impact: 50,
    }

    setDiscoveries((prev) => [newDiscovery, ...prev])
    setSelectedDiscovery(newDiscovery.id)
    addAuditEntry(newDiscovery.id, "observe", "Created discovery", "New discovery project started")
  }

  const discoveryStats = {
    total: discoveries.length,
    byPhase: discoveries.reduce(
      (acc, d) => {
        acc[d.phase] = (acc[d.phase] || 0) + 1
        return acc
      },
      {} as Record<string, number>,
    ),
    avgConfidence: discoveries.reduce((sum, d) => sum + d.confidence, 0) / discoveries.length,
    avgImpact: discoveries.reduce((sum, d) => sum + d.impact, 0) / discoveries.length,
  }

  const pieData = Object.entries(discoveryStats.byPhase).map(([phase, count]) => ({
    name: phase,
    value: count,
    color: phaseColors[phase as keyof typeof phaseColors],
  }))

  return (
    <div className="space-y-6">
      <Tabs defaultValue="workflow" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="workflow">Discovery Workflow</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="audit">Audit Log</TabsTrigger>
        </TabsList>

        <TabsContent value="workflow" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Discovery List */}
            <Card className="lg:col-span-1">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Search className="h-5 w-5" />
                    Discoveries
                  </CardTitle>
                  <Button size="sm" onClick={createNewDiscovery}>
                    <Lightbulb className="h-4 w-4 mr-2" />
                    New
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {discoveries.map((discovery) => {
                  const PhaseIcon = phaseIcons[discovery.phase]
                  return (
                    <Card
                      key={discovery.id}
                      className={`cursor-pointer transition-all ${
                        selectedDiscovery === discovery.id ? "ring-2 ring-primary" : ""
                      }`}
                      onClick={() => setSelectedDiscovery(discovery.id)}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-start gap-3">
                          <div
                            className={`w-8 h-8 rounded-full ${phaseColors[discovery.phase]} flex items-center justify-center`}
                          >
                            <PhaseIcon className="h-4 w-4 text-white" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <h4 className="font-medium text-sm truncate">{discovery.title}</h4>
                            <p className="text-xs text-muted-foreground capitalize">{discovery.phase}</p>
                            <div className="flex gap-2 mt-2">
                              <Badge variant="outline" className="text-xs">
                                {discovery.confidence}% confidence
                              </Badge>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </CardContent>
            </Card>

            {/* Main Workflow */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>{selectedDiscoveryData?.title}</CardTitle>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="capitalize">
                      {selectedDiscoveryData?.phase}
                    </Badge>
                    <Button size="sm" onClick={advancePhase} disabled={selectedDiscoveryData?.phase === "completed"}>
                      Next Phase
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Tabs value={selectedDiscoveryData?.phase} className="w-full">
                  <TabsList className="grid w-full grid-cols-5">
                    <TabsTrigger value="observe" className="flex items-center gap-2">
                      <Eye className="h-4 w-4" />
                      Observe
                    </TabsTrigger>
                    <TabsTrigger value="reflect" className="flex items-center gap-2">
                      <Brain className="h-4 w-4" />
                      Reflect
                    </TabsTrigger>
                    <TabsTrigger value="invent" className="flex items-center gap-2">
                      <Lightbulb className="h-4 w-4" />
                      Invent
                    </TabsTrigger>
                    <TabsTrigger value="execute" className="flex items-center gap-2">
                      <Play className="h-4 w-4" />
                      Execute
                    </TabsTrigger>
                    <TabsTrigger value="completed" className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4" />
                      Complete
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="observe" className="space-y-4 mt-6">
                    <div className="space-y-3">
                      <h3 className="font-semibold">Observations</h3>
                      {selectedDiscoveryData?.observations.map((obs, index) => (
                        <Card key={index}>
                          <CardContent className="p-3">
                            <p className="text-sm">{obs}</p>
                          </CardContent>
                        </Card>
                      ))}
                      <div className="flex gap-2">
                        <Textarea
                          placeholder="Add new observation..."
                          value={newObservation}
                          onChange={(e) => setNewObservation(e.target.value)}
                          className="flex-1"
                        />
                        <Button onClick={addObservation}>Add</Button>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="reflect" className="space-y-4 mt-6">
                    <div className="space-y-3">
                      <h3 className="font-semibold">Reflections</h3>
                      {selectedDiscoveryData?.reflections.map((ref, index) => (
                        <Card key={index}>
                          <CardContent className="p-3">
                            <p className="text-sm">{ref}</p>
                          </CardContent>
                        </Card>
                      ))}
                      <div className="flex gap-2">
                        <Textarea
                          placeholder="Add reflection or analysis..."
                          value={newReflection}
                          onChange={(e) => setNewReflection(e.target.value)}
                          className="flex-1"
                        />
                        <Button onClick={addReflection}>Add</Button>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="invent" className="space-y-4 mt-6">
                    <div className="space-y-3">
                      <h3 className="font-semibold">Hypotheses</h3>
                      {selectedDiscoveryData?.hypotheses.map((hyp, index) => (
                        <Card key={index}>
                          <CardContent className="p-3">
                            <p className="text-sm">{hyp}</p>
                          </CardContent>
                        </Card>
                      ))}
                      <div className="flex gap-2">
                        <Textarea
                          placeholder="Propose new hypothesis..."
                          value={newHypothesis}
                          onChange={(e) => setNewHypothesis(e.target.value)}
                          className="flex-1"
                        />
                        <Button onClick={addHypothesis}>Add</Button>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="execute" className="space-y-4 mt-6">
                    <div className="space-y-3">
                      <h3 className="font-semibold">Experiments</h3>
                      {selectedDiscoveryData?.experiments.map((exp, index) => (
                        <Card key={index}>
                          <CardContent className="p-3">
                            <p className="text-sm">{exp}</p>
                          </CardContent>
                        </Card>
                      ))}
                      <div className="flex gap-2">
                        <Textarea
                          placeholder="Design new experiment..."
                          value={newExperiment}
                          onChange={(e) => setNewExperiment(e.target.value)}
                          className="flex-1"
                        />
                        <Button onClick={addExperiment}>Add</Button>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="completed" className="space-y-4 mt-6">
                    <div className="text-center py-8">
                      <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold">Discovery Complete</h3>
                      <p className="text-muted-foreground">This discovery has been completed and documented.</p>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Beaker className="h-4 w-4 text-primary" />
                  <span className="text-sm font-medium">Total Discoveries</span>
                </div>
                <div className="text-2xl font-bold">{discoveryStats.total}</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-4 w-4 text-green-500" />
                  <span className="text-sm font-medium">Avg Confidence</span>
                </div>
                <div className="text-2xl font-bold">{discoveryStats.avgConfidence.toFixed(1)}%</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 text-orange-500" />
                  <span className="text-sm font-medium">Avg Impact</span>
                </div>
                <div className="text-2xl font-bold">{discoveryStats.avgImpact.toFixed(1)}%</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-blue-500" />
                  <span className="text-sm font-medium">Active</span>
                </div>
                <div className="text-2xl font-bold">{discoveries.filter((d) => d.phase !== "completed").length}</div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Discovery Phases Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={pieData}
                        cx="50%"
                        cy="50%"
                        outerRadius={80}
                        dataKey="value"
                        label={({ name, value }) => `${name}: ${value}`}
                      >
                        {pieData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={`rgb(var(--chart-${(index % 5) + 1}))`} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Confidence vs Impact</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {discoveries.map((discovery) => (
                    <div key={discovery.id} className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="truncate">{discovery.title}</span>
                        <span>
                          {discovery.confidence}% / {discovery.impact}%
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <Progress value={discovery.confidence} className="h-2" />
                        <Progress value={discovery.impact} className="h-2" />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="audit" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Audit Log
              </CardTitle>
              <CardDescription>Complete history of discovery activities</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {auditLog.map((entry) => (
                  <Card key={entry.id}>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className="text-xs capitalize">
                              {entry.phase}
                            </Badge>
                            <span className="text-sm font-medium">{entry.action}</span>
                          </div>
                          <p className="text-sm text-muted-foreground">{entry.details}</p>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <Clock className="h-3 w-3" />
                            {entry.timestamp.toLocaleString()}
                            <span>by {entry.user}</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
