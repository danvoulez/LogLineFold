"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"
import { Upload, Download, RotateCcw, Play, Pause, Zap, Eye, Shuffle } from "lucide-react"

interface DNABase {
  base: "A" | "T" | "G" | "C"
  position: number
  x: number
  y: number
  z: number
}

interface DNAStrand {
  bases: DNABase[]
  complementary: DNABase[]
}

export function DNAViewer() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [dnaSequence, setDnaSequence] = useState("ATCGATCGATCGATCG")
  const [rotation, setRotation] = useState([0])
  const [zoom, setZoom] = useState([1])
  const [isAnimating, setIsAnimating] = useState(false)
  const [mutationRate, setMutationRate] = useState([0.1])
  const [fusionMode, setFusionMode] = useState(false)
  const [selectedBase, setSelectedBase] = useState<number | null>(null)

  // Generate complementary DNA strand
  const getComplement = (base: string): string => {
    const complements: { [key: string]: string } = { A: "T", T: "A", G: "C", C: "G" }
    return complements[base] || "A"
  }

  // Generate random DNA sequence
  const generateRandomDNA = (length = 16): string => {
    const bases = ["A", "T", "G", "C"]
    return Array.from({ length }, () => bases[Math.floor(Math.random() * bases.length)]).join("")
  }

  // Simulate mutation
  const simulateMutation = () => {
    const bases = ["A", "T", "G", "C"]
    const sequence = dnaSequence.split("")
    const numMutations = Math.floor(sequence.length * mutationRate[0])

    for (let i = 0; i < numMutations; i++) {
      const randomIndex = Math.floor(Math.random() * sequence.length)
      const currentBase = sequence[randomIndex]
      const availableBases = bases.filter((base) => base !== currentBase)
      sequence[randomIndex] = availableBases[Math.floor(Math.random() * availableBases.length)]
    }

    setDnaSequence(sequence.join(""))
  }

  // Draw DNA helix on canvas
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const width = canvas.width
    const height = canvas.height
    const centerX = width / 2
    const centerY = height / 2

    // Clear canvas
    ctx.fillStyle = "rgb(var(--background))"
    ctx.fillRect(0, 0, width, height)

    // Draw DNA helix
    const helixRadius = 80 * zoom[0]
    const helixHeight = height * 0.8
    const turns = 3
    const baseSpacing = helixHeight / dnaSequence.length

    ctx.strokeStyle = "rgb(var(--primary))"
    ctx.lineWidth = 3

    // Draw helix backbone
    ctx.beginPath()
    for (let i = 0; i <= 100; i++) {
      const t = i / 100
      const y = centerY - helixHeight / 2 + t * helixHeight
      const angle = t * turns * 2 * Math.PI + rotation[0] * 0.1
      const x1 = centerX + Math.cos(angle) * helixRadius
      const x2 = centerX + Math.cos(angle + Math.PI) * helixRadius

      if (i === 0) {
        ctx.moveTo(x1, y)
      } else {
        ctx.lineTo(x1, y)
      }
    }
    ctx.stroke()

    ctx.beginPath()
    for (let i = 0; i <= 100; i++) {
      const t = i / 100
      const y = centerY - helixHeight / 2 + t * helixHeight
      const angle = t * turns * 2 * Math.PI + rotation[0] * 0.1 + Math.PI
      const x = centerX + Math.cos(angle) * helixRadius

      if (i === 0) {
        ctx.moveTo(x, y)
      } else {
        ctx.lineTo(x, y)
      }
    }
    ctx.stroke()

    // Draw base pairs
    dnaSequence.split("").forEach((base, index) => {
      const t = index / (dnaSequence.length - 1)
      const y = centerY - helixHeight / 2 + t * helixHeight
      const angle = t * turns * 2 * Math.PI + rotation[0] * 0.1
      const x1 = centerX + Math.cos(angle) * helixRadius
      const x2 = centerX + Math.cos(angle + Math.PI) * helixRadius
      const complement = getComplement(base)

      // Base pair connection
      ctx.strokeStyle = fusionMode ? "rgb(var(--accent))" : "rgb(var(--muted-foreground))"
      ctx.lineWidth = 2
      ctx.beginPath()
      ctx.moveTo(x1, y)
      ctx.lineTo(x2, y)
      ctx.stroke()

      // Base circles
      const baseColors: { [key: string]: string } = {
        A: "rgb(var(--chart-1))",
        T: "rgb(var(--chart-2))",
        G: "rgb(var(--chart-3))",
        C: "rgb(var(--chart-4))",
      }

      // Left base
      ctx.fillStyle = baseColors[base] || "rgb(var(--muted))"
      ctx.beginPath()
      ctx.arc(x1, y, selectedBase === index ? 8 : 6, 0, 2 * Math.PI)
      ctx.fill()

      // Right base (complement)
      ctx.fillStyle = baseColors[complement] || "rgb(var(--muted))"
      ctx.beginPath()
      ctx.arc(x2, y, 6, 0, 2 * Math.PI)
      ctx.fill()

      // Base labels
      ctx.fillStyle = "rgb(var(--foreground))"
      ctx.font = "12px monospace"
      ctx.textAlign = "center"
      ctx.fillText(base, x1, y + 4)
      ctx.fillText(complement, x2, y + 4)
    })
  }, [dnaSequence, rotation, zoom, fusionMode, selectedBase])

  // Animation loop
  useEffect(() => {
    if (!isAnimating) return

    const interval = setInterval(() => {
      setRotation((prev) => [(prev[0] + 1) % 360])
    }, 50)

    return () => clearInterval(interval)
  }, [isAnimating])

  return (
    <div className="space-y-6">
      <Tabs defaultValue="visualizer" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="visualizer">Visualizer</TabsTrigger>
          <TabsTrigger value="import">Import DNA</TabsTrigger>
          <TabsTrigger value="generate">Generate</TabsTrigger>
          <TabsTrigger value="mutations">Mutations</TabsTrigger>
        </TabsList>

        <TabsContent value="visualizer" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="h-5 w-5" />
                DNA Helix Visualization
              </CardTitle>
              <CardDescription>Interactive 3D DNA double helix with base pair highlighting</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Canvas for DNA visualization */}
              <div className="relative">
                <canvas
                  ref={canvasRef}
                  width={600}
                  height={400}
                  className="border border-border rounded-lg bg-card w-full"
                  onClick={(e) => {
                    const rect = e.currentTarget.getBoundingClientRect()
                    const y = e.clientY - rect.top
                    const baseIndex = Math.floor((y / rect.height) * dnaSequence.length)
                    setSelectedBase(baseIndex)
                  }}
                />
                {fusionMode && <Badge className="absolute top-2 right-2 bg-accent">Fusion View Active</Badge>}
              </div>

              {/* Controls */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Rotation: {rotation[0]}°</Label>
                  <Slider value={rotation} onValueChange={setRotation} max={360} step={1} className="w-full" />
                </div>
                <div className="space-y-2">
                  <Label>Zoom: {zoom[0].toFixed(1)}x</Label>
                  <Slider value={zoom} onValueChange={setZoom} min={0.5} max={2} step={0.1} className="w-full" />
                </div>
                <div className="flex gap-2">
                  <Button
                    variant={isAnimating ? "default" : "outline"}
                    size="sm"
                    onClick={() => setIsAnimating(!isAnimating)}
                  >
                    {isAnimating ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                  </Button>
                  <Button
                    variant={fusionMode ? "default" : "outline"}
                    size="sm"
                    onClick={() => setFusionMode(!fusionMode)}
                  >
                    Fusion View
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => setRotation([0])}>
                    <RotateCcw className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Sequence display */}
              <div className="space-y-2">
                <Label>Current Sequence ({dnaSequence.length} bases)</Label>
                <div className="font-mono text-sm bg-muted p-3 rounded-lg break-all">
                  {dnaSequence.split("").map((base, index) => (
                    <span
                      key={index}
                      className={`${selectedBase === index ? "bg-primary text-primary-foreground px-1 rounded" : ""}`}
                    >
                      {base}
                    </span>
                  ))}
                </div>
                <div className="font-mono text-sm bg-muted p-3 rounded-lg break-all">
                  {dnaSequence.split("").map((base, index) => (
                    <span key={index}>{getComplement(base)}</span>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="import" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="h-5 w-5" />
                Import Real DNA Data
              </CardTitle>
              <CardDescription>Load DNA sequences from FASTA files or paste sequences directly</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="dna-input">DNA Sequence</Label>
                <Input
                  id="dna-input"
                  value={dnaSequence}
                  onChange={(e) => setDnaSequence(e.target.value.toUpperCase().replace(/[^ATGC]/g, ""))}
                  placeholder="Enter DNA sequence (A, T, G, C only)"
                  className="font-mono"
                />
              </div>
              <div className="flex gap-2">
                <Button variant="outline" className="flex-1 bg-transparent">
                  <Upload className="h-4 w-4 mr-2" />
                  Upload FASTA
                </Button>
                <Button variant="outline" className="flex-1 bg-transparent">
                  <Download className="h-4 w-4 mr-2" />
                  Export Sequence
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="generate" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shuffle className="h-5 w-5" />
                Generate Symbolic DNA
              </CardTitle>
              <CardDescription>Create random or patterned DNA sequences for analysis</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <Button onClick={() => setDnaSequence(generateRandomDNA(16))} variant="outline">
                  Random 16bp
                </Button>
                <Button onClick={() => setDnaSequence(generateRandomDNA(32))} variant="outline">
                  Random 32bp
                </Button>
                <Button onClick={() => setDnaSequence("ATCGATCGATCGATCG")} variant="outline">
                  Repeating Pattern
                </Button>
                <Button onClick={() => setDnaSequence("AAAATTTTGGGGCCCC")} variant="outline">
                  Base Blocks
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="mutations" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5" />
                Mutation Simulation
              </CardTitle>
              <CardDescription>Simulate genetic mutations and observe their effects</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Mutation Rate: {(mutationRate[0] * 100).toFixed(1)}%</Label>
                <Slider
                  value={mutationRate}
                  onValueChange={setMutationRate}
                  min={0}
                  max={1}
                  step={0.01}
                  className="w-full"
                />
              </div>
              <Button onClick={simulateMutation} className="w-full">
                <Zap className="h-4 w-4 mr-2" />
                Apply Mutations
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
