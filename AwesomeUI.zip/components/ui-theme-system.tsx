"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Palette, Monitor, Sun, Moon, Dna, Eye, EyeOff, Minimize2, Maximize2, Zap } from "lucide-react"

interface ThemeConfig {
  id: string
  name: string
  description: string
  colors: {
    primary: string
    secondary: string
    accent: string
    background: string
    foreground: string
  }
  dnaMapping: {
    A: string
    T: string
    G: string
    C: string
  }
}

interface UIFoldState {
  sidebar: boolean
  header: boolean
  panelHeaders: boolean
  charts: boolean
  controls: boolean
}

export function UIThemeSystem() {
  const [currentTheme, setCurrentTheme] = useState("default")
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [customColors, setCustomColors] = useState({
    primary: [200],
    secondary: [280],
    accent: [60],
  })
  const [uiFoldState, setUIFoldState] = useState<UIFoldState>({
    sidebar: true,
    header: true,
    panelHeaders: true,
    charts: true,
    controls: true,
  })
  const [dnaThemeEnabled, setDnaThemeEnabled] = useState(false)
  const [animationSpeed, setAnimationSpeed] = useState([1])
  const [compactMode, setCompactMode] = useState(false)

  const themes: ThemeConfig[] = [
    {
      id: "default",
      name: "Scientific Blue",
      description: "Clean and professional scientific interface",
      colors: {
        primary: "oklch(0.55 0.15 200)",
        secondary: "oklch(0.65 0.2 280)",
        accent: "oklch(0.65 0.2 60)",
        background: "oklch(1 0 0)",
        foreground: "oklch(0.35 0 0)",
      },
      dnaMapping: {
        A: "oklch(0.55 0.15 200)",
        T: "oklch(0.65 0.2 280)",
        G: "oklch(0.55 0.25 25)",
        C: "oklch(0.65 0.2 150)",
      },
    },
    {
      id: "biotech",
      name: "Biotech Green",
      description: "Nature-inspired biotechnology theme",
      colors: {
        primary: "oklch(0.6 0.2 150)",
        secondary: "oklch(0.7 0.15 120)",
        accent: "oklch(0.65 0.25 80)",
        background: "oklch(0.98 0.02 150)",
        foreground: "oklch(0.2 0.05 150)",
      },
      dnaMapping: {
        A: "oklch(0.6 0.2 150)",
        T: "oklch(0.7 0.15 120)",
        G: "oklch(0.65 0.25 80)",
        C: "oklch(0.55 0.2 180)",
      },
    },
    {
      id: "quantum",
      name: "Quantum Purple",
      description: "Futuristic quantum computing aesthetic",
      colors: {
        primary: "oklch(0.65 0.25 280)",
        secondary: "oklch(0.7 0.2 320)",
        accent: "oklch(0.6 0.3 260)",
        background: "oklch(0.05 0.02 280)",
        foreground: "oklch(0.9 0.05 280)",
      },
      dnaMapping: {
        A: "oklch(0.65 0.25 280)",
        T: "oklch(0.7 0.2 320)",
        G: "oklch(0.6 0.3 260)",
        C: "oklch(0.75 0.15 300)",
      },
    },
    {
      id: "medical",
      name: "Medical Red",
      description: "Clinical and medical research theme",
      colors: {
        primary: "oklch(0.6 0.25 25)",
        secondary: "oklch(0.65 0.2 15)",
        accent: "oklch(0.7 0.15 45)",
        background: "oklch(0.99 0.01 25)",
        foreground: "oklch(0.25 0.05 25)",
      },
      dnaMapping: {
        A: "oklch(0.6 0.25 25)",
        T: "oklch(0.65 0.2 15)",
        G: "oklch(0.7 0.15 45)",
        C: "oklch(0.55 0.2 5)",
      },
    },
  ]

  const currentThemeConfig = themes.find((t) => t.id === currentTheme) || themes[0]

  // Apply theme changes to CSS variables
  useEffect(() => {
    const root = document.documentElement
    if (currentThemeConfig) {
      root.style.setProperty("--primary", currentThemeConfig.colors.primary)
      root.style.setProperty("--secondary", currentThemeConfig.colors.secondary)
      root.style.setProperty("--accent", currentThemeConfig.colors.accent)

      if (dnaThemeEnabled) {
        root.style.setProperty("--chart-1", currentThemeConfig.dnaMapping.A)
        root.style.setProperty("--chart-2", currentThemeConfig.dnaMapping.T)
        root.style.setProperty("--chart-3", currentThemeConfig.dnaMapping.G)
        root.style.setProperty("--chart-4", currentThemeConfig.dnaMapping.C)
      }
    }

    // Apply dark mode
    if (isDarkMode) {
      root.classList.add("dark")
    } else {
      root.classList.remove("dark")
    }

    // Apply compact mode
    if (compactMode) {
      root.style.setProperty("--radius", "0.25rem")
    } else {
      root.style.setProperty("--radius", "0.5rem")
    }
  }, [currentTheme, currentThemeConfig, isDarkMode, dnaThemeEnabled, compactMode])

  const toggleUIElement = (element: keyof UIFoldState) => {
    setUIFoldState((prev) => ({
      ...prev,
      [element]: !prev[element],
    }))
  }

  const resetToDefaults = () => {
    setCurrentTheme("default")
    setIsDarkMode(false)
    setCustomColors({ primary: [200], secondary: [280], accent: [60] })
    setUIFoldState({
      sidebar: true,
      header: true,
      panelHeaders: true,
      charts: true,
      controls: true,
    })
    setDnaThemeEnabled(false)
    setAnimationSpeed([1])
    setCompactMode(false)
  }

  const exportTheme = () => {
    const themeExport = {
      theme: currentTheme,
      darkMode: isDarkMode,
      customColors,
      uiFoldState,
      dnaThemeEnabled,
      animationSpeed: animationSpeed[0],
      compactMode,
    }

    const blob = new Blob([JSON.stringify(themeExport, null, 2)], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "logline-theme.json"
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="themes" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="themes">Theme Switcher</TabsTrigger>
          <TabsTrigger value="folding">UI Folding</TabsTrigger>
          <TabsTrigger value="dna-themes">DNA Themes</TabsTrigger>
        </TabsList>

        <TabsContent value="themes" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Theme Selection */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Palette className="h-5 w-5" />
                  Theme Selection
                </CardTitle>
                <CardDescription>Choose from predefined themes or customize your own</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Theme Grid */}
                <div className="grid grid-cols-1 gap-3">
                  {themes.map((theme) => (
                    <Card
                      key={theme.id}
                      className={`cursor-pointer transition-all ${
                        currentTheme === theme.id ? "ring-2 ring-primary" : ""
                      }`}
                      onClick={() => setCurrentTheme(theme.id)}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="flex gap-1">
                            <div className="w-4 h-4 rounded-full" style={{ backgroundColor: theme.colors.primary }} />
                            <div className="w-4 h-4 rounded-full" style={{ backgroundColor: theme.colors.secondary }} />
                            <div className="w-4 h-4 rounded-full" style={{ backgroundColor: theme.colors.accent }} />
                          </div>
                          <div>
                            <div className="font-medium">{theme.name}</div>
                            <div className="text-sm text-muted-foreground">{theme.description}</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                {/* Mode Controls */}
                <div className="space-y-3 pt-4 border-t">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {isDarkMode ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
                      <Label>Dark Mode</Label>
                    </div>
                    <Switch checked={isDarkMode} onCheckedChange={setIsDarkMode} />
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Minimize2 className="h-4 w-4" />
                      <Label>Compact Mode</Label>
                    </div>
                    <Switch checked={compactMode} onCheckedChange={setCompactMode} />
                  </div>
                </div>

                {/* Animation Speed */}
                <div className="space-y-2">
                  <Label>Animation Speed: {animationSpeed[0]}x</Label>
                  <Slider
                    value={animationSpeed}
                    onValueChange={setAnimationSpeed}
                    min={0.1}
                    max={3}
                    step={0.1}
                    className="w-full"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Theme Preview */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Monitor className="h-5 w-5" />
                  Live Preview
                </CardTitle>
                <CardDescription>See how your theme looks in real-time</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Preview Components */}
                <div className="space-y-3 p-4 border rounded-lg">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 bg-primary rounded" />
                    <span className="font-medium">Primary Color</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 bg-secondary rounded" />
                    <span className="font-medium">Secondary Color</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 bg-accent rounded" />
                    <span className="font-medium">Accent Color</span>
                  </div>
                </div>

                {/* DNA Base Preview */}
                {dnaThemeEnabled && (
                  <div className="space-y-3 p-4 border rounded-lg">
                    <h4 className="font-medium">DNA Base Colors</h4>
                    <div className="grid grid-cols-2 gap-2">
                      {Object.entries(currentThemeConfig.dnaMapping).map(([base, color]) => (
                        <div key={base} className="flex items-center gap-2">
                          <div className="w-4 h-4 rounded-full" style={{ backgroundColor: color }} />
                          <span className="font-mono text-sm">{base}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={resetToDefaults}>
                    Reset
                  </Button>
                  <Button variant="outline" size="sm" onClick={exportTheme}>
                    Export
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="folding" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Maximize2 className="h-5 w-5" />
                UI Folding Controls
              </CardTitle>
              <CardDescription>Show or hide interface elements to customize your workspace</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {Object.entries(uiFoldState).map(([element, isVisible]) => (
                  <Card key={element}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {isVisible ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                          <span className="font-medium capitalize">{element.replace(/([A-Z])/g, " $1")}</span>
                        </div>
                        <Switch
                          checked={isVisible}
                          onCheckedChange={() => toggleUIElement(element as keyof UIFoldState)}
                        />
                      </div>
                      <p className="text-sm text-muted-foreground mt-2">
                        {isVisible ? "Currently visible" : "Currently hidden"}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Fold State Summary */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Current UI State</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {Object.entries(uiFoldState).map(([element, isVisible]) => (
                      <Badge key={element} variant={isVisible ? "default" : "secondary"}>
                        {element}: {isVisible ? "Visible" : "Hidden"}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="dna-themes" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Dna className="h-5 w-5" />
                DNA Theme Linking
              </CardTitle>
              <CardDescription>
                Link visual elements to genetic data for enhanced scientific visualization
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* DNA Theme Toggle */}
              <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                <div className="flex items-center gap-2">
                  <Zap className="h-4 w-4" />
                  <span className="font-medium">Enable DNA Theme Linking</span>
                </div>
                <Switch checked={dnaThemeEnabled} onCheckedChange={setDnaThemeEnabled} />
              </div>

              {dnaThemeEnabled && (
                <>
                  {/* DNA Base Color Mapping */}
                  <div className="space-y-3">
                    <h3 className="font-semibold">DNA Base Color Mapping</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {Object.entries(currentThemeConfig.dnaMapping).map(([base, color]) => (
                        <Card key={base}>
                          <CardContent className="p-4">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-full" style={{ backgroundColor: color }} />
                              <div>
                                <div className="font-mono font-bold">{base}</div>
                                <div className="text-sm text-muted-foreground">
                                  {base === "A" && "Adenine"}
                                  {base === "T" && "Thymine"}
                                  {base === "G" && "Guanine"}
                                  {base === "C" && "Cytosine"}
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>

                  {/* DNA Visualization Options */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Visualization Options</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex items-center justify-between">
                        <Label>Color-code DNA sequences</Label>
                        <Switch defaultChecked />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label>Apply to chart elements</Label>
                        <Switch defaultChecked />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label>Sync with agent genomes</Label>
                        <Switch defaultChecked />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label>Animate base transitions</Label>
                        <Switch />
                      </div>
                    </CardContent>
                  </Card>

                  {/* Sample DNA Sequence Preview */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">DNA Sequence Preview</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="font-mono text-lg p-4 bg-muted rounded-lg">
                        {"ATCGATCGATCGATCG".split("").map((base, index) => (
                          <span
                            key={index}
                            className="px-1 py-0.5 rounded mr-1"
                            style={{
                              backgroundColor:
                                currentThemeConfig.dnaMapping[base as keyof typeof currentThemeConfig.dnaMapping],
                              color: "white",
                            }}
                          >
                            {base}
                          </span>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
