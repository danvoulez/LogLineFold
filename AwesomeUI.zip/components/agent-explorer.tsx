"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from "recharts"
import { Bot, Play, Pause, Zap, Brain, GitBranch } from "lucide-react"

interface Agent {
  id: string
  name: string
  genome: string
  fitness: number
  generation: number
  status: "active" | "idle" | "evolving" | "terminated"
  trajectory: { x: number; y: number; fitness: number; generation: number }[]
  mutations: number
  performance: {
    accuracy: number
    speed: number
    adaptability: number
    efficiency: number
    stability: number
  }
}

interface MutationEvent {
  agentId: string
  generation: number
  type: "point" | "insertion" | "deletion" | "crossover"
  position: number
  oldBase: string
  newBase: string
  fitnessChange: number
}

export function AgentExplorer() {
  const [agents, setAgents] = useState<Agent[]>([
    {
      id: "agent-001",
      name: "Alpha Genome",
      genome: "ATCGATCGATCGATCGATCGATCG",
      fitness: 85.2,
      generation: 15,
      status: "active",
      trajectory: Array.from({ length: 15 }, (_, i) => ({
        x: i,
        y: 50 + 20 * Math.sin(i * 0.3) + Math.random() * 10,
        fitness: 40 + i * 2 + Math.random() * 15,
        generation: i,
      })),
      mutations: 12,
      performance: { accuracy: 85, speed: 78, adaptability: 92, efficiency: 80, stability: 88 },
    },
    {
      id: "agent-002",
      name: "Beta Variant",
      genome: "GCTAGCTAGCTAGCTAGCTAGCTA",
      fitness: 72.8,
      generation: 12,
      status: "evolving",
      trajectory: Array.from({ length: 12 }, (_, i) => ({
        x: i,
        y: 40 + 15 * Math.cos(i * 0.4) + Math.random() * 8,
        fitness: 35 + i * 2.5 + Math.random() * 12,
        generation: i,
      })),
      mutations: 8,
      performance: { accuracy: 73, speed: 85, adaptability: 68, efficiency: 75, stability: 70 },
    },
    {
      id: "agent-003",
      name: "Gamma Explorer",
      genome: "TACGTACGTACGTACGTACGTACG",
      fitness: 91.5,
      generation: 20,
      status: "active",
      trajectory: Array.from({ length: 20 }, (_, i) => ({
        x: i,
        y: 60 + 25 * Math.sin(i * 0.2) + Math.random() * 12,
        fitness: 45 + i * 2.2 + Math.random() * 18,
        generation: i,
      })),
      mutations: 18,
      performance: { accuracy: 92, speed: 88, adaptability: 95, efficiency: 90, stability: 85 },
    },
  ])

  const [selectedAgent, setSelectedAgent] = useState<string | null>("agent-001")
  const [isSimulating, setIsSimulating] = useState(false)
  const [mutationRate, setMutationRate] = useState([0.05])
  const [selectionPressure, setSelectionPressure] = useState([0.7])
  const [populationSize, setPopulationSize] = useState([10])

  const [mutationHistory, setMutationHistory] = useState<MutationEvent[]>([
    {
      agentId: "agent-001",
      generation: 14,
      type: "point",
      position: 5,
      oldBase: "A",
      newBase: "G",
      fitnessChange: 2.3,
    },
    {
      agentId: "agent-002",
      generation: 11,
      type: "insertion",
      position: 8,
      oldBase: "",
      newBase: "C",
      fitnessChange: -1.2,
    },
    {
      agentId: "agent-003",
      generation: 19,
      type: "crossover",
      position: 12,
      oldBase: "T",
      newBase: "A",
      fitnessChange: 4.1,
    },
  ])

  // Simulation loop
  useEffect(() => {
    if (!isSimulating) return

    const interval = setInterval(() => {
      setAgents((prev) =>
        prev.map((agent) => {
          if (agent.status === "active" || agent.status === "evolving") {
            const newGeneration = agent.generation + 1
            const fitnessChange = (Math.random() - 0.5) * 10
            const newFitness = Math.max(0, Math.min(100, agent.fitness + fitnessChange))

            // Simulate mutations
            let newGenome = agent.genome
            if (Math.random() < mutationRate[0]) {
              const bases = ["A", "T", "G", "C"]
              const position = Math.floor(Math.random() * newGenome.length)
              const newBase = bases[Math.floor(Math.random() * bases.length)]
              newGenome = newGenome.substring(0, position) + newBase + newGenome.substring(position + 1)

              // Add mutation event
              setMutationHistory((prev) => [
                ...prev.slice(-9),
                {
                  agentId: agent.id,
                  generation: newGeneration,
                  type: "point",
                  position,
                  oldBase: agent.genome[position],
                  newBase,
                  fitnessChange,
                },
              ])
            }

            return {
              ...agent,
              generation: newGeneration,
              fitness: newFitness,
              genome: newGenome,
              mutations: agent.mutations + (newGenome !== agent.genome ? 1 : 0),
              trajectory: [
                ...agent.trajectory,
                {
                  x: newGeneration,
                  y: 50 + 30 * Math.sin(newGeneration * 0.2) + Math.random() * 15,
                  fitness: newFitness,
                  generation: newGeneration,
                },
              ].slice(-50),
              performance: {
                accuracy: Math.max(0, Math.min(100, agent.performance.accuracy + (Math.random() - 0.5) * 5)),
                speed: Math.max(0, Math.min(100, agent.performance.speed + (Math.random() - 0.5) * 3)),
                adaptability: Math.max(0, Math.min(100, agent.performance.adaptability + (Math.random() - 0.5) * 4)),
                efficiency: Math.max(0, Math.min(100, agent.performance.efficiency + (Math.random() - 0.5) * 3)),
                stability: Math.max(0, Math.min(100, agent.performance.stability + (Math.random() - 0.5) * 2)),
              },
            }
          }
          return agent
        }),
      )
    }, 1000)

    return () => clearInterval(interval)
  }, [isSimulating, mutationRate])

  const selectedAgentData = agents.find((agent) => agent.id === selectedAgent)

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-500"
      case "evolving":
        return "bg-blue-500"
      case "idle":
        return "bg-yellow-500"
      case "terminated":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  const getStatusText = (status: string) => {
    return status.charAt(0).toUpperCase() + status.slice(1)
  }

  const getMutationTypeColor = (type: string) => {
    switch (type) {
      case "point":
        return "text-blue-600"
      case "insertion":
        return "text-green-600"
      case "deletion":
        return "text-red-600"
      case "crossover":
        return "text-purple-600"
      default:
        return "text-gray-600"
    }
  }

  const createNewAgent = () => {
    const bases = ["A", "T", "G", "C"]
    const genome = Array.from({ length: 24 }, () => bases[Math.floor(Math.random() * bases.length)]).join("")
    const newAgent: Agent = {
      id: `agent-${Date.now()}`,
      name: `Agent ${agents.length + 1}`,
      genome,
      fitness: 50 + Math.random() * 30,
      generation: 0,
      status: "active",
      trajectory: [{ x: 0, y: 50, fitness: 50, generation: 0 }],
      mutations: 0,
      performance: {
        accuracy: 50 + Math.random() * 30,
        speed: 50 + Math.random() * 30,
        adaptability: 50 + Math.random() * 30,
        efficiency: 50 + Math.random() * 30,
        stability: 50 + Math.random() * 30,
      },
    }
    setAgents((prev) => [...prev, newAgent])
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="dashboard" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="dashboard">Agent Dashboard</TabsTrigger>
          <TabsTrigger value="trajectory">Trajectory View</TabsTrigger>
          <TabsTrigger value="mutations">Mutation Panel</TabsTrigger>
        </TabsList>

        <TabsContent value="dashboard" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bot className="h-5 w-5" />
                Genome-Based Agents
              </CardTitle>
              <CardDescription>Monitor and control AI agents with genetic algorithms</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Simulation Controls */}
              <div className="flex items-center gap-4 p-4 bg-muted/50 rounded-lg">
                <Button
                  variant={isSimulating ? "default" : "outline"}
                  size="sm"
                  onClick={() => setIsSimulating(!isSimulating)}
                >
                  {isSimulating ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                  {isSimulating ? "Pause" : "Start"} Evolution
                </Button>
                <Button variant="outline" size="sm" onClick={createNewAgent}>
                  <Bot className="h-4 w-4 mr-2" />
                  Create Agent
                </Button>
                <div className="flex-1" />
                <Badge variant="secondary">Population: {agents.length}</Badge>
                <Badge variant="outline">
                  Avg Fitness: {(agents.reduce((sum, a) => sum + a.fitness, 0) / agents.length).toFixed(1)}
                </Badge>
              </div>

              {/* Agent Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {agents.map((agent) => (
                  <Card
                    key={agent.id}
                    className={`cursor-pointer transition-all ${selectedAgent === agent.id ? "ring-2 ring-primary" : ""}`}
                    onClick={() => setSelectedAgent(agent.id)}
                  >
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-base">{agent.name}</CardTitle>
                        <div className="flex items-center gap-2">
                          <div className={`w-2 h-2 rounded-full ${getStatusColor(agent.status)}`} />
                          <Badge variant="outline" className="text-xs">
                            {getStatusText(agent.status)}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Fitness:</span>
                          <span className="font-medium">{agent.fitness.toFixed(1)}%</span>
                        </div>
                        <Progress value={agent.fitness} />
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground">
                        <div>Gen: {agent.generation}</div>
                        <div>Mutations: {agent.mutations}</div>
                      </div>
                      <div className="font-mono text-xs bg-muted p-2 rounded truncate">
                        {agent.genome.substring(0, 16)}...
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Selected Agent Details */}
              {selectedAgentData && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Brain className="h-5 w-5" />
                      {selectedAgentData.name} - Performance Profile
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <RadarChart
                          data={Object.entries(selectedAgentData.performance).map(([key, value]) => ({
                            metric: key,
                            value,
                          }))}
                        >
                          <PolarGrid />
                          <PolarAngleAxis dataKey="metric" />
                          <PolarRadiusAxis angle={90} domain={[0, 100]} />
                          <Radar
                            name="Performance"
                            dataKey="value"
                            stroke="rgb(var(--primary))"
                            fill="rgb(var(--primary) / 0.3)"
                            strokeWidth={2}
                          />
                        </RadarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="trajectory" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <GitBranch className="h-5 w-5" />
                Agent Trajectory Visualization
              </CardTitle>
              <CardDescription>Track agent evolution paths and fitness progression</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Fitness Evolution Chart */}
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="generation" />
                    <YAxis />
                    <Tooltip />
                    {agents.map((agent, index) => (
                      <Line
                        key={agent.id}
                        data={agent.trajectory}
                        type="monotone"
                        dataKey="fitness"
                        stroke={`rgb(var(--chart-${(index % 5) + 1}))`}
                        strokeWidth={selectedAgent === agent.id ? 3 : 2}
                        name={agent.name}
                        opacity={selectedAgent === agent.id ? 1 : 0.6}
                      />
                    ))}
                  </LineChart>
                </ResponsiveContainer>
              </div>

              {/* Trajectory Scatter Plot */}
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <ScatterChart>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="x" name="Generation" />
                    <YAxis dataKey="y" name="Exploration" />
                    <Tooltip cursor={{ strokeDasharray: "3 3" }} />
                    {agents.map((agent, index) => (
                      <Scatter
                        key={agent.id}
                        data={agent.trajectory}
                        fill={`rgb(var(--chart-${(index % 5) + 1}))`}
                        name={agent.name}
                      />
                    ))}
                  </ScatterChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="mutations" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5" />
                Mutation Control Panel
              </CardTitle>
              <CardDescription>Configure genetic algorithm parameters and monitor mutations</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Mutation Parameters */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Mutation Rate: {(mutationRate[0] * 100).toFixed(1)}%</Label>
                  <Slider value={mutationRate} onValueChange={setMutationRate} min={0} max={0.2} step={0.001} />
                </div>
                <div className="space-y-2">
                  <Label>Selection Pressure: {selectionPressure[0].toFixed(2)}</Label>
                  <Slider value={selectionPressure} onValueChange={setSelectionPressure} min={0} max={1} step={0.01} />
                </div>
                <div className="space-y-2">
                  <Label>Population Size: {populationSize[0]}</Label>
                  <Slider value={populationSize} onValueChange={setPopulationSize} min={5} max={50} step={1} />
                </div>
              </div>

              {/* Mutation History */}
              <div className="space-y-3">
                <h3 className="text-lg font-semibold">Recent Mutations</h3>
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {mutationHistory
                    .slice(-10)
                    .reverse()
                    .map((mutation, index) => (
                      <Card key={index} className="p-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <Badge variant="outline" className={getMutationTypeColor(mutation.type)}>
                              {mutation.type}
                            </Badge>
                            <span className="text-sm font-medium">
                              {agents.find((a) => a.id === mutation.agentId)?.name}
                            </span>
                            <span className="text-xs text-muted-foreground">Gen {mutation.generation}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-mono">
                              {mutation.oldBase} → {mutation.newBase}
                            </span>
                            <Badge variant={mutation.fitnessChange > 0 ? "default" : "destructive"} className="text-xs">
                              {mutation.fitnessChange > 0 ? "+" : ""}
                              {mutation.fitnessChange.toFixed(1)}
                            </Badge>
                          </div>
                        </div>
                      </Card>
                    ))}
                </div>
              </div>

              {/* Manual Mutation Controls */}
              {selectedAgentData && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Manual Mutation - {selectedAgentData.name}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="font-mono text-sm bg-muted p-3 rounded">{selectedAgentData.genome}</div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        Point Mutation
                      </Button>
                      <Button variant="outline" size="sm">
                        Insert Base
                      </Button>
                      <Button variant="outline" size="sm">
                        Delete Base
                      </Button>
                      <Button variant="outline" size="sm">
                        Crossover
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
