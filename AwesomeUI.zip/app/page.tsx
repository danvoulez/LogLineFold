"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Dna, Baseline as Timeline, Bot, Lightbulb, Palette, Menu, X } from "lucide-react"
import { DNAViewer } from "@/components/dna-viewer"
import { SpanTimeline } from "@/components/span-timeline"
import { AgentExplorer } from "@/components/agent-explorer"
import { DiscoveryPanel } from "@/components/discovery-panel"
import { UIThemeSystem } from "@/components/ui-theme-system"

interface Panel {
  id: string
  label: string
  component: string
  features: string[]
  icon: React.ComponentType<any>
}

const panels: Panel[] = [
  {
    id: "dna_panel",
    label: "DNA Viewer",
    component: "genome.visualizer",
    features: ["import_real_dna", "generate_symbolic", "fusion_view", "mutation_sim"],
    icon: Dna,
  },
  {
    id: "span_panel",
    label: "Span Timeline",
    component: "span.timeline",
    features: ["span_fold", "protein_expression", "ΔS_visualizer"],
    icon: Timeline,
  },
  {
    id: "agent_panel",
    label: "Agent Explorer",
    component: "agent.dashboard",
    features: ["genome_based_agent", "trajectory_view", "mutation_panel"],
    icon: Bot,
  },
  {
    id: "discovery_panel",
    label: "Discoveries",
    component: "symbolic.loop",
    features: ["observe", "reflect", "invent", "execute", "audit_log"],
    icon: Lightbulb,
  },
  {
    id: "render_panel",
    label: "UI & Theme",
    component: "ui.styler",
    features: ["fold_ui", "style_switcher", "dna_theme_link"],
    icon: Palette,
  },
]

export default function LogLinePage() {
  const [activePanel, setActivePanel] = useState("dna_panel")
  const [sidebarOpen, setSidebarOpen] = useState(true)

  const activePanelData = panels.find((panel) => panel.id === activePanel)

  const renderPanelContent = () => {
    switch (activePanel) {
      case "dna_panel":
        return <DNAViewer />
      case "span_panel":
        return <SpanTimeline />
      case "agent_panel":
        return <AgentExplorer />
      case "discovery_panel":
        return <DiscoveryPanel />
      case "render_panel":
        return <UIThemeSystem />
      default:
        return (
          <Card className="min-h-[400px]">
            <CardHeader>
              <CardTitle>Panel Content</CardTitle>
              <CardDescription>{activePanelData?.label} interface will be implemented here</CardDescription>
            </CardHeader>
            <CardContent className="flex items-center justify-center h-64">
              <div className="text-center space-y-4">
                {activePanelData && <activePanelData.icon className="h-16 w-16 text-muted-foreground mx-auto" />}
                <p className="text-muted-foreground">{activePanelData?.label} panel coming soon...</p>
              </div>
            </CardContent>
          </Card>
        )
    }
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm">
        <div className="flex h-16 items-center justify-between px-6">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={() => setSidebarOpen(!sidebarOpen)} className="lg:hidden">
              {sidebarOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </Button>
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
                <Dna className="h-5 w-5 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-xl font-bold">LogLine</h1>
                <p className="text-xs text-muted-foreground">Bioinformatics Platform</p>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="text-xs">
              Runtime: Active
            </Badge>
            <Badge variant="outline" className="text-xs">
              Identity: dan
            </Badge>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar Navigation */}
        <aside
          className={`${sidebarOpen ? "w-64" : "w-0"} transition-all duration-300 overflow-hidden border-r border-border bg-sidebar`}
        >
          <div className="p-4">
            <h2 className="text-sm font-semibold text-sidebar-foreground mb-4">Panels</h2>
            <nav className="space-y-2">
              {panels.map((panel) => {
                const Icon = panel.icon
                return (
                  <Button
                    key={panel.id}
                    variant={activePanel === panel.id ? "default" : "ghost"}
                    className="w-full justify-start gap-3 h-auto p-3"
                    onClick={() => setActivePanel(panel.id)}
                  >
                    <Icon className="h-4 w-4" />
                    <div className="text-left">
                      <div className="font-medium">{panel.label}</div>
                      <div className="text-xs text-muted-foreground">{panel.component}</div>
                    </div>
                  </Button>
                )
              })}
            </nav>
          </div>
        </aside>

        {/* Main Content Area */}
        <main className="flex-1 p-6">
          {activePanelData && (
            <div className="space-y-6">
              {/* Panel Header */}
              <div className="flex items-center gap-4">
                <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center">
                  <activePanelData.icon className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold">{activePanelData.label}</h2>
                  <p className="text-muted-foreground">Component: {activePanelData.component}</p>
                </div>
              </div>

              {/* Panel Content */}
              {renderPanelContent()}
            </div>
          )}
        </main>
      </div>
    </div>
  )
}
